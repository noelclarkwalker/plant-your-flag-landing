Mail Room QA v5 screenshots (fixture testing)
==========================================
JPEG screenshots for visual review.
Not live WordPress validation.
Visual approval pending.
